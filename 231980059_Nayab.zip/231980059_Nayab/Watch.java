public class Watch{

	private double price;
	private double weight;

	//Default Constructor
	public Watch()
	{
		this.price = 0.0;
		this.weight = 0.0;
	}

	//Overloaded Constructor
	public Watch(double price,double weight)
	{
		this.price = price;
		this.weight = weight;
	}

	//Setters
	public void setPrice(double price)
	{
		this.price = price;
	}
	public void setWeight(double weight)
	{
		this.weight = weight;
	}

	//Getters
	public double getPrice()
	{
		return this.price;
	}
	public double getWeight()
	{
		return this.weight;
	}

	//Display Method
	public void display()
	{
		System.out.println("Price  :  "+getPrice()+"  weight  :  "+getWeight());
	}
}