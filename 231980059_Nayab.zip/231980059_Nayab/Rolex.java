public class Rolex extends Watch{

	private String faceColor;
	private String strapType;

	//Default Constructor
	public Rolex()
	{
		super();
		this.faceColor = "Null";
		this.strapType = "Null";
	}

	//2 Argumented Overloaded Costructor
	public Rolex(String faceColor,String strapType)
	{
		this.faceColor = faceColor;
		this.strapType = strapType;
	}

	//4 Argumented Overloaded Constructor
	public Rolex(String faceColor,String strapType,double price,double weight)
	{
		super(price,weight);
		this.faceColor = faceColor;
		this.strapType = strapType;
	}

	//Setters
	public void setFaceColor(String faceColor)
	{
		this.faceColor = faceColor;
	}
	public void setStrapType(String strapType)
	{
		this.strapType = strapType;
	}

	//Getters
	public String getFaceColor()
	{
		return this.faceColor;
	}
	public String getStrapType()
	{
		return this.strapType;
	}

	//Display Method
	public void display()
	{
		super.display();
		System.out.println("Face Color :  "+getFaceColor()+"  Strap Type  :  "+getStrapType());
	}
}