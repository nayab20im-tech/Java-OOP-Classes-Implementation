public class UsingWatch{

	public static void main(String[] args) {
		
		Rolex r1 = new Rolex();
		Rolex r2 = new Rolex("Red","Leather");
		Rolex r3 = new Rolex("Blue","Stainless Steel",100.0,20.0);

		System.out.println("Object 1");
		r1.display();
		System.out.println();
		System.out.println("Object 2");
		r2.display();
		System.out.println();
		System.out.println("Object 3");
		r3.display();
	}
}